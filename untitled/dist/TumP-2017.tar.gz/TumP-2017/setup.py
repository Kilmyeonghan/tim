from distutils.core import setup

setup(
    name='TumP',
    version='2017',
    packages=[''],
    url='',
    license='',
    author='명한',
    author_email='',
    description=''
)
